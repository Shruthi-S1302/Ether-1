$("#submit").click(function () {
  $("#post").printThis({
    importCSS: true,
    importStyle: true,
    loadCSS: "C:/Users/Shruthi/Documents/GitHub/ether/post.css",
  });
});
